#Data for the email

EMAIL_ADDRESS = "riskandfraudclass@gmail.com"
PASSWORD = "bigdata18"
MAIL = "alvarofq@student.ie.edu"