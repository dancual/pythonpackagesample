def  datareader_doc():
    """ function to return the string 'Group C first package that anyone can install it! How cool!!!' """
    return("Group C first package that anyone can install it! How cool!!!")
