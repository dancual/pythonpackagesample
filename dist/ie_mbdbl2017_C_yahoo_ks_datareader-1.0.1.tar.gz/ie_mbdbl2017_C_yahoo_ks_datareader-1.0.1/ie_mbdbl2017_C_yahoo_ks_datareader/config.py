#Data for the email

EMAIL_ADDRESS = "riskandfraudclass@gmail.com"
PASSWORD = "bigdata18"
MAIL = ["alvarofq@student.ie.edu",
        "daniel.serrano@student.ie.edu",
        "marcos.amoretti@student.ie.edu",
        "markus.schaber@student.ie.edu",
        "V.Mahecha@student.ie.edu",
        "yamil.zeledon@student.ie.edu"]
#MAIL = ["alicia.fbc@student.ie.edu",
#        "alvarofq@student.ie.edu",
#        "andrea@student.ie.edu",
#        "bego.delafuente@student.ie.edu",
#        "catherine.kaloki@student.ie.edu",
#        "daniel.serrano@student.ie.edu",
#        "davidvanrhede@student.ie.edu",
#        "dlichti@student.ie.edu",
#        "gp013500@student.ie.edu",
#        "jwenzl@student.ie.edu",
#        "Kunal.Panchal@student.ie.edu",
#        "leo.mutuku@student.ie.edu",
#        "M.Hurayki@student.ie.edu",
#        "marcos.amoretti@student.ie.edu",
#        "markus.schaber@student.ie.edu",
#        "mate.dugandzic@student.ie.edu",
#        "michel.aa@student.ie.edu",
#        "rima.nakhala@student.ie.edu",
#        "Serhatong@student.ie.edu",
#        "V.Mahecha@student.ie.edu",
#        "yamil.zeledon@student.ie.edu",
#        "mfalonso@faculty.ie.edu"]
